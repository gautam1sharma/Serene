// Topic 3: Form Validation & Client-Side Interactivity - Interactive Script

document.addEventListener('DOMContentLoaded', function() {
    
    // ===== FLOATING OBJECTS INTERACTION (Same as Topic 1 & 2) =====
    const floatingObjects = document.querySelectorAll('.floating-object');
    let draggedElement = null;
    let offsetX = 0;
    let offsetY = 0;
    let isDragging = false;
    
    floatingObjects.forEach(obj => {
        obj.addEventListener('mousedown', function(e) {
            if (e.button === 0) {
                isDragging = true;
                draggedElement = this;
                this.classList.add('dragging');
                
                const rect = this.getBoundingClientRect();
                offsetX = e.clientX - rect.left - rect.width / 2;
                offsetY = e.clientY - rect.top - rect.height / 2;
                this.style.animationPlayState = 'paused';
                e.preventDefault();
            }
        });
        
        obj.addEventListener('mouseenter', function() {
            if (!isDragging) this.style.animationPlayState = 'paused';
        });
        
        obj.addEventListener('mouseleave', function() {
            if (!isDragging) this.style.animationPlayState = 'running';
        });
    });
    
    document.addEventListener('mousemove', function(e) {
        if (isDragging && draggedElement) {
            const container = draggedElement.parentElement;
            const containerRect = container.getBoundingClientRect();
            const objRect = draggedElement.getBoundingClientRect();
            
            let newX = e.clientX - containerRect.left - offsetX - objRect.width / 2;
            let newY = e.clientY - containerRect.top - offsetY - objRect.height / 2;
            
            const padding = 10;
            newX = Math.max(padding, Math.min(newX, containerRect.width - objRect.width - padding));
            newY = Math.max(padding, Math.min(newY, containerRect.height - objRect.height - padding));
            
            draggedElement.style.left = newX + 'px';
            draggedElement.style.top = newY + 'px';
            draggedElement.style.transform = 'scale(1.1)';
        }
    });
    
    document.addEventListener('mouseup', function(e) {
        if (isDragging && draggedElement) {
            draggedElement.classList.remove('dragging');
            draggedElement.style.animationPlayState = 'running';
            draggedElement.style.transform = '';
            draggedElement = null;
            isDragging = false;
        }
    });

    
    // Theme Toggle
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;
    const logoDark = document.getElementById('logo-dark');
    const logoLight = document.getElementById('logo-light');
    
    const currentTheme = localStorage.getItem('theme') || 'dark';
    if (currentTheme === 'light') {
        body.classList.add('light-theme');
        if (logoDark && logoLight) {
            logoDark.style.display = 'none';
            logoLight.style.display = 'block';
        }
    }
    
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            body.classList.toggle('light-theme');
            
            if (logoDark && logoLight) {
                if (body.classList.contains('light-theme')) {
                    logoDark.style.display = 'none';
                    logoLight.style.display = 'block';
                } else {
                    logoDark.style.display = 'block';
                    logoLight.style.display = 'none';
                }
            }
            
            const theme = body.classList.contains('light-theme') ? 'light' : 'dark';
            localStorage.setItem('theme', theme);
            
            this.style.transform = 'scale(0.9)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    }
    
    // Slide Navigation
    let currentSlide = 1;
    const totalSlides = 15;
    
    function updateSlideCounter() {
        document.getElementById('current-slide').textContent = currentSlide;
        document.getElementById('total-slides').textContent = totalSlides;
    }
    
    function showSlide(slideNumber) {
        document.querySelectorAll('.slide').forEach(slide => {
            slide.classList.remove('active');
        });
        
        const targetSlide = document.querySelector(`[data-slide="${slideNumber}"]`);
        if (targetSlide) {
            targetSlide.classList.add('active');
            currentSlide = slideNumber;
            updateSlideCounter();
            
            document.getElementById('prev-btn').disabled = currentSlide === 1;
            document.getElementById('next-btn').disabled = currentSlide === totalSlides;
        }
    }
    
    document.getElementById('prev-btn').addEventListener('click', function() {
        if (currentSlide > 1) showSlide(currentSlide - 1);
    });
    
    document.getElementById('next-btn').addEventListener('click', function() {
        if (currentSlide < totalSlides) showSlide(currentSlide + 1);
    });
    
    document.addEventListener('keydown', function(event) {
        if (event.key === 'ArrowLeft' && currentSlide > 1) {
            showSlide(currentSlide - 1);
        } else if (event.key === 'ArrowRight' && currentSlide < totalSlides) {
            showSlide(currentSlide + 1);
        }
    });
    
    updateSlideCounter();

    // ===== SLIDE 2: Validation Impact Demo =====
    const noValidationForm = document.getElementById('no-validation-form');
    const withValidationForm = document.getElementById('with-validation-form');
    const noValResult = document.getElementById('no-val-result');
    const withValResult = document.getElementById('with-val-result');
    
    if (noValidationForm) {
        noValidationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            noValResult.textContent = '✅ Form submitted (even with invalid data!)';
            noValResult.className = 'result-box success';
        });
    }
    
    if (withValidationForm) {
        withValidationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('val-email').value;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (!email) {
                withValResult.textContent = '❌ Email is required!';
                withValResult.className = 'result-box error';
            } else if (!emailRegex.test(email)) {
                withValResult.textContent = '❌ Invalid email format!';
                withValResult.className = 'result-box error';
            } else {
                withValResult.textContent = '✅ Form submitted successfully!';
                withValResult.className = 'result-box success';
            }
        });
    }
    
    // ===== SLIDE 3: HTML5 Validation =====
    const html5Form = document.getElementById('html5-form');
    const html5Result = document.getElementById('html5-result');
    
    if (html5Form) {
        html5Form.addEventListener('submit', function(e) {
            e.preventDefault();
            html5Result.textContent = '✅ All HTML5 validations passed!';
            html5Result.style.background = 'linear-gradient(135deg, #27ae60 0%, #229954 100%)';
            html5Result.style.color = 'white';
            html5Result.style.padding = '15px';
            html5Result.style.borderRadius = '6px';
        });
    }
    
    // ===== SLIDE 4: Credit Card Validator =====
    const cardInput = document.getElementById('card-input');
    const cardDisplay = document.getElementById('card-display');
    const cardValidation = document.getElementById('card-validation');
    const cardTypes = document.querySelectorAll('.card-type');
    const testCardBtns = document.querySelectorAll('.test-card-btn');
    
    // Add click handlers for test card buttons
    if (testCardBtns) {
        testCardBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const cardNumber = this.dataset.card;
                const formatted = cardNumber.match(/.{1,4}/g)?.join(' ') || cardNumber;
                cardInput.value = formatted;
                
                // Trigger input event to validate
                const event = new Event('input', { bubbles: true });
                cardInput.dispatchEvent(event);
            });
        });
    }
    
    if (cardInput) {
        cardInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s/g, '');
            let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
            e.target.value = formattedValue;
            
            cardDisplay.textContent = formattedValue || '#### #### #### ####';
            
            // Detect card type
            cardTypes.forEach(type => type.classList.remove('active'));
            
            if (value.startsWith('4')) {
                document.querySelector('[data-type="visa"]').classList.add('active');
            } else if (value.startsWith('5')) {
                document.querySelector('[data-type="mastercard"]').classList.add('active');
            } else if (value.startsWith('3')) {
                document.querySelector('[data-type="amex"]').classList.add('active');
            }
            
            // Luhn algorithm validation
            if (value.length >= 13) {
                const isValid = luhnCheck(value);
                if (isValid) {
                    cardValidation.textContent = '✅ Valid card number!';
                    cardValidation.className = 'validation-message valid';
                } else {
                    cardValidation.textContent = '❌ Invalid card number!';
                    cardValidation.className = 'validation-message invalid';
                }
            } else {
                cardValidation.textContent = '';
            }
        });
    }
    
    function luhnCheck(cardNumber) {
        let sum = 0;
        let isEven = false;
        
        for (let i = cardNumber.length - 1; i >= 0; i--) {
            let digit = parseInt(cardNumber[i]);
            
            if (isEven) {
                digit *= 2;
                if (digit > 9) digit -= 9;
            }
            
            sum += digit;
            isEven = !isEven;
        }
        
        return sum % 10 === 0;
    }

    // ===== SLIDE 5: Username Availability Checker =====
    const usernameInput = document.getElementById('username-input');
    const usernameIcon = document.getElementById('username-icon');
    const usernameMessage = document.getElementById('username-message');
    const rules = {
        length: document.getElementById('rule-length'),
        alphanumeric: document.getElementById('rule-alphanumeric'),
        lowercase: document.getElementById('rule-lowercase'),
        available: document.getElementById('rule-available')
    };
    
    const takenUsernames = ['admin', 'user', 'test', 'demo', 'root'];
    
    if (usernameInput) {
        usernameInput.addEventListener('input', function() {
            const value = this.value;
            let allValid = true;
            
            // Check length
            if (value.length >= 3) {
                rules.length.classList.add('valid');
                rules.length.classList.remove('invalid');
            } else {
                rules.length.classList.add('invalid');
                rules.length.classList.remove('valid');
                allValid = false;
            }
            
            // Check alphanumeric
            if (/^[a-zA-Z0-9]*$/.test(value)) {
                rules.alphanumeric.classList.add('valid');
                rules.alphanumeric.classList.remove('invalid');
            } else {
                rules.alphanumeric.classList.add('invalid');
                rules.alphanumeric.classList.remove('valid');
                allValid = false;
            }
            
            // Check starts with letter
            if (/^[a-zA-Z]/.test(value)) {
                rules.lowercase.classList.add('valid');
                rules.lowercase.classList.remove('invalid');
            } else {
                rules.lowercase.classList.add('invalid');
                rules.lowercase.classList.remove('valid');
                allValid = false;
            }
            
            // Check availability
            if (value.length >= 3 && !takenUsernames.includes(value.toLowerCase())) {
                rules.available.classList.add('valid');
                rules.available.classList.remove('invalid');
            } else if (value.length >= 3) {
                rules.available.classList.add('invalid');
                rules.available.classList.remove('valid');
                allValid = false;
            }
            
            // Update icon and message
            if (value.length === 0) {
                usernameIcon.textContent = '';
                usernameMessage.textContent = '';
            } else if (allValid) {
                usernameIcon.textContent = '✅';
                usernameMessage.textContent = '✅ Username is available!';
                usernameMessage.style.color = '#27ae60';
            } else {
                usernameIcon.textContent = '❌';
                usernameMessage.textContent = '❌ Username does not meet requirements';
                usernameMessage.style.color = '#e74c3c';
            }
        });
    }
    
    // ===== SLIDE 6: Regex Pattern Tester =====
    const regexInput = document.getElementById('regex-input');
    const currentPattern = document.getElementById('current-pattern');
    const regexIcon = document.getElementById('regex-icon');
    const regexText = document.getElementById('regex-text');
    const exampleList = document.getElementById('example-list');
    const patternBtns = document.querySelectorAll('.pattern-btn');
    
    const patterns = {
        email: {
            regex: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
            pattern: '/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/',
            examples: ['user@example.com', 'test@test.co.uk', 'invalid@', '@invalid.com']
        },
        phone: {
            regex: /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/,
            pattern: '/^\\(?([0-9]{3})\\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/',
            examples: ['(123) 456-7890', '123-456-7890', '1234567890', '123-45-6789']
        },
        url: {
            regex: /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/,
            pattern: '/^(https?:\\/\\/)([\\da-z\\.-]+)\\.([a-z\\.]{2,6})([/\\w \\.-]*)*\\/?$/',
            examples: ['https://example.com', 'www.test.com', 'example.com/path', 'not a url']
        },
        zipcode: {
            regex: /^\d{5}(-\d{4})?$/,
            pattern: '/^\\d{5}(-\\d{4})?$/',
            examples: ['12345', '12345-6789', '1234', '12345-678']
        }
    };
    
    let currentPatternType = 'email';
    
    function updateExamples() {
        if (exampleList) {
            exampleList.innerHTML = '';
            patterns[currentPatternType].examples.forEach(example => {
                const span = document.createElement('span');
                span.className = 'example-item';
                span.textContent = example;
                span.addEventListener('click', function() {
                    regexInput.value = example;
                    testPattern(example);
                });
                exampleList.appendChild(span);
            });
        }
    }
    
    function testPattern(value) {
        const regex = patterns[currentPatternType].regex;
        const isValid = regex.test(value);
        
        if (isValid) {
            regexIcon.textContent = '✅';
            regexIcon.style.color = '#27ae60';
            regexText.textContent = 'Pattern matches!';
            regexText.style.color = '#27ae60';
        } else {
            regexIcon.textContent = '❌';
            regexIcon.style.color = '#e74c3c';
            regexText.textContent = 'Pattern does not match';
            regexText.style.color = '#e74c3c';
        }
    }
    
    if (patternBtns) {
        patternBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                patternBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                currentPatternType = this.dataset.pattern;
                currentPattern.textContent = patterns[currentPatternType].pattern;
                updateExamples();
                
                if (regexInput.value) {
                    testPattern(regexInput.value);
                }
            });
        });
    }
    
    if (regexInput) {
        regexInput.addEventListener('input', function() {
            if (this.value) {
                testPattern(this.value);
            } else {
                regexIcon.textContent = '?';
                regexIcon.style.color = '#7a7a9a';
                regexText.textContent = 'Enter text to test the pattern';
                regexText.style.color = '#b0b0c8';
            }
        });
    }
    
    updateExamples();
    
    // ===== SLIDE 7: Password Strength Checker =====
    const passwordInput = document.getElementById('password-input');
    const togglePassword = document.getElementById('toggle-password');
    const strengthBar = document.getElementById('strength-bar');
    const strengthText = document.getElementById('strength-text');
    const requirements = {
        length: document.getElementById('req-length'),
        lowercase: document.getElementById('req-lowercase'),
        uppercase: document.getElementById('req-uppercase'),
        number: document.getElementById('req-number'),
        special: document.getElementById('req-special')
    };
    
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.type === 'password' ? 'text' : 'password';
            passwordInput.type = type;
            this.textContent = type === 'password' ? '👁️' : '🙈';
        });
    }
    
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            const value = this.value;
            let strength = 0;
            
            // Check length
            if (value.length >= 8) {
                requirements.length.classList.add('met');
                strength++;
            } else {
                requirements.length.classList.remove('met');
            }
            
            // Check lowercase
            if (/[a-z]/.test(value)) {
                requirements.lowercase.classList.add('met');
                strength++;
            } else {
                requirements.lowercase.classList.remove('met');
            }
            
            // Check uppercase
            if (/[A-Z]/.test(value)) {
                requirements.uppercase.classList.add('met');
                strength++;
            } else {
                requirements.uppercase.classList.remove('met');
            }
            
            // Check number
            if (/[0-9]/.test(value)) {
                requirements.number.classList.add('met');
                strength++;
            } else {
                requirements.number.classList.remove('met');
            }
            
            // Check special character
            if (/[!@#$%^&*(),.?":{}|<>]/.test(value)) {
                requirements.special.classList.add('met');
                strength++;
            } else {
                requirements.special.classList.remove('met');
            }
            
            // Update strength bar
            strengthBar.className = 'strength-bar';
            if (strength === 0) {
                strengthText.textContent = 'Enter a password';
                strengthText.style.color = '#7a7a9a';
            } else if (strength === 1) {
                strengthBar.classList.add('weak');
                strengthText.textContent = 'Weak password';
                strengthText.style.color = '#e74c3c';
            } else if (strength === 2) {
                strengthBar.classList.add('fair');
                strengthText.textContent = 'Fair password';
                strengthText.style.color = '#f39c12';
            } else if (strength === 3) {
                strengthBar.classList.add('good');
                strengthText.textContent = 'Good password';
                strengthText.style.color = '#f1c40f';
            } else if (strength === 4) {
                strengthBar.classList.add('strong');
                strengthText.textContent = 'Strong password';
                strengthText.style.color = '#3498db';
            } else if (strength === 5) {
                strengthBar.classList.add('very-strong');
                strengthText.textContent = 'Very strong password!';
                strengthText.style.color = '#27ae60';
            }
        });
    }

    // ===== SLIDE 8: Registration Form =====
    const registrationForm = document.getElementById('registration-form');
    const registrationResult = document.getElementById('registration-result');
    
    if (registrationForm) {
        registrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const firstName = document.getElementById('firstName').value.trim();
            const lastName = document.getElementById('lastName').value.trim();
            const regEmail = document.getElementById('regEmail').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const regPassword = document.getElementById('regPassword').value;
            const terms = document.getElementById('terms').checked;
            
            let errors = [];
            
            // Clear previous errors
            document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
            
            // Validate first name
            if (!firstName || firstName.length < 2) {
                document.getElementById('firstName-error').textContent = 'First name must be at least 2 characters';
                errors.push('firstName');
            }
            
            // Validate last name
            if (!lastName || lastName.length < 2) {
                document.getElementById('lastName-error').textContent = 'Last name must be at least 2 characters';
                errors.push('lastName');
            }
            
            // Validate email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(regEmail)) {
                document.getElementById('regEmail-error').textContent = 'Please enter a valid email';
                errors.push('email');
            }
            
            // Validate phone
            const phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
            if (!phoneRegex.test(phone)) {
                document.getElementById('phone-error').textContent = 'Please enter a valid phone number';
                errors.push('phone');
            }
            
            // Validate password
            if (regPassword.length < 8) {
                document.getElementById('regPassword-error').textContent = 'Password must be at least 8 characters';
                errors.push('password');
            }
            
            // Validate terms
            if (!terms) {
                document.getElementById('terms-error').textContent = 'You must agree to the terms';
                errors.push('terms');
            }
            
            // Show result
            if (errors.length === 0) {
                registrationResult.textContent = '✅ Registration successful! Welcome aboard!';
                registrationResult.className = 'submission-result success';
                registrationForm.reset();
            } else {
                registrationResult.textContent = `❌ Please fix ${errors.length} error(s) above`;
                registrationResult.className = 'submission-result error';
            }
        });
    }
    
    // ===== SLIDE 9: Interactive Components =====
    const notifToggle = document.getElementById('notif-toggle');
    const notifStatus = document.getElementById('notif-status');
    const volumeSlider = document.getElementById('volume-slider');
    const volumeValue = document.getElementById('volume-value');
    const themeDropdown = document.getElementById('theme-dropdown');
    const showModalBtn = document.getElementById('show-modal-btn');
    const demoModal = document.getElementById('demo-modal');
    const modalClose = document.querySelector('.modal-close');
    const modalOkBtn = document.getElementById('modal-ok-btn');
    const interactionLog = document.getElementById('interaction-log');
    
    function logInteraction(message) {
        if (interactionLog) {
            const timestamp = new Date().toLocaleTimeString();
            interactionLog.innerHTML += `[${timestamp}] ${message}\n`;
            interactionLog.scrollTop = interactionLog.scrollHeight;
        }
    }
    
    if (notifToggle) {
        notifToggle.addEventListener('change', function() {
            notifStatus.textContent = this.checked ? 'On' : 'Off';
            notifStatus.style.color = this.checked ? '#27ae60' : '#e74c3c';
            logInteraction(`Notifications turned ${this.checked ? 'ON' : 'OFF'}`);
        });
    }
    
    if (volumeSlider) {
        volumeSlider.addEventListener('input', function() {
            volumeValue.textContent = this.value;
            logInteraction(`Volume set to ${this.value}%`);
        });
    }
    
    if (themeDropdown) {
        const selected = themeDropdown.querySelector('.dropdown-selected');
        const options = themeDropdown.querySelector('.dropdown-options');
        
        // Set initial value based on current theme
        if (body.classList.contains('light-theme')) {
            selected.textContent = 'Light Theme';
        } else {
            selected.textContent = 'Dark Theme';
        }
        
        selected.addEventListener('click', function() {
            themeDropdown.classList.toggle('open');
        });
        
        themeDropdown.querySelectorAll('.dropdown-option').forEach(option => {
            option.addEventListener('click', function() {
                const value = this.dataset.value;
                selected.textContent = this.textContent;
                themeDropdown.classList.remove('open');
                
                // Actually change the theme
                if (value === 'light') {
                    body.classList.add('light-theme');
                    localStorage.setItem('theme', 'light');
                    if (logoDark && logoLight) {
                        logoDark.style.display = 'none';
                        logoLight.style.display = 'block';
                    }
                    logInteraction('Theme changed to: Light Theme');
                } else if (value === 'dark') {
                    body.classList.remove('light-theme');
                    localStorage.setItem('theme', 'dark');
                    if (logoDark && logoLight) {
                        logoDark.style.display = 'block';
                        logoLight.style.display = 'none';
                    }
                    logInteraction('Theme changed to: Dark Theme');
                } else if (value === 'auto') {
                    // Auto theme based on system preference
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                    if (prefersDark) {
                        body.classList.remove('light-theme');
                        localStorage.setItem('theme', 'dark');
                        if (logoDark && logoLight) {
                            logoDark.style.display = 'block';
                            logoLight.style.display = 'none';
                        }
                    } else {
                        body.classList.add('light-theme');
                        localStorage.setItem('theme', 'light');
                        if (logoDark && logoLight) {
                            logoDark.style.display = 'none';
                            logoLight.style.display = 'block';
                        }
                    }
                    logInteraction('Theme changed to: Auto (System Preference)');
                }
            });
        });
        
        document.addEventListener('click', function(e) {
            if (!themeDropdown.contains(e.target)) {
                themeDropdown.classList.remove('open');
            }
        });
    }
    
    if (showModalBtn) {
        showModalBtn.addEventListener('click', function() {
            demoModal.classList.add('show');
            logInteraction('Modal opened');
        });
    }
    
    if (modalClose) {
        modalClose.addEventListener('click', function() {
            demoModal.classList.remove('show');
            logInteraction('Modal closed');
        });
    }
    
    if (modalOkBtn) {
        modalOkBtn.addEventListener('click', function() {
            demoModal.classList.remove('show');
            logInteraction('Modal confirmed');
        });
    }
    
    if (demoModal) {
        demoModal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
                logInteraction('Modal closed (clicked outside)');
            }
        });
    }
    
    // Tooltip
    const tooltipBtn = document.getElementById('show-tooltip-btn');
    if (tooltipBtn) {
        tooltipBtn.addEventListener('mouseenter', function() {
            logInteraction('Tooltip displayed on hover');
        });
        
        tooltipBtn.addEventListener('mouseleave', function() {
            logInteraction('Tooltip hidden');
        });
    }
    
    // ===== SLIDE 10: File Upload =====
    const uploadArea = document.getElementById('upload-area');
    const fileInput = document.getElementById('file-input');
    const filePreview = document.getElementById('file-preview');
    const fileInfo = document.getElementById('file-info');
    
    if (uploadArea) {
        uploadArea.addEventListener('click', function() {
            fileInput.click();
        });
        
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', function() {
            this.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                handleFile(files[0]);
            }
        });
    }
    
    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            if (e.target.files.length > 0) {
                handleFile(e.target.files[0]);
            }
        });
    }
    
    function handleFile(file) {
        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        
        fileInfo.innerHTML = '';
        
        if (file.size > maxSize) {
            fileInfo.innerHTML = '<p style="color: #e74c3c;">❌ File too large! Maximum size is 5MB.</p>';
            return;
        }
        
        if (!allowedTypes.includes(file.type)) {
            fileInfo.innerHTML = '<p style="color: #e74c3c;">❌ Invalid file type! Only JPG, PNG, GIF, and WebP are allowed.</p>';
            return;
        }
        
        // Show preview
        const reader = new FileReader();
        reader.onload = function(e) {
            filePreview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
        };
        reader.readAsDataURL(file);
        
        // Show file info
        const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
        fileInfo.innerHTML = `
            <p style="color: #27ae60;">✅ File uploaded successfully!</p>
            <p><strong>Name:</strong> ${file.name}</p>
            <p><strong>Size:</strong> ${sizeInMB} MB</p>
            <p><strong>Type:</strong> ${file.type}</p>
        `;
    }
    
    // ===== SLIDE 12: Security Demo =====
    const unsafeInput = document.getElementById('unsafe-input');
    const sanitizeBtn = document.getElementById('sanitize-btn');
    const unsafeOutput = document.getElementById('unsafe-output');
    const safeOutput = document.getElementById('safe-output');
    
    if (sanitizeBtn) {
        sanitizeBtn.addEventListener('click', function() {
            const input = unsafeInput.value;
            
            // Unsafe output (for demonstration only - don't do this in production!)
            unsafeOutput.textContent = `Raw input: ${input}`;
            
            // Safe output (sanitized)
            const div = document.createElement('div');
            div.textContent = input;
            safeOutput.textContent = `Sanitized: ${div.innerHTML}`;
        });
    }

    
    // ===== SLIDE 14: Contact Form =====
    const contactForm = document.getElementById('contact-form');
    const contactResult = document.getElementById('contact-result');
    const contactMessage = document.getElementById('contact-message');
    const charCount = document.getElementById('char-count');
    
    if (contactMessage) {
        contactMessage.addEventListener('input', function() {
            const length = this.value.length;
            charCount.textContent = length;
            
            if (length > 500) {
                charCount.style.color = '#e74c3c';
                this.value = this.value.substring(0, 500);
            } else if (length > 450) {
                charCount.style.color = '#f39c12';
            } else {
                charCount.style.color = '#7a7a9a';
            }
        });
    }
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('contact-name').value.trim();
            const email = document.getElementById('contact-email').value.trim();
            const subject = document.getElementById('contact-subject').value;
            const message = document.getElementById('contact-message').value.trim();
            
            let errors = [];
            
            // Clear previous errors
            document.querySelectorAll('.error-msg').forEach(el => el.textContent = '');
            
            // Validate name
            if (!name || name.length < 2) {
                document.getElementById('contact-name-error').textContent = 'Name is required';
                errors.push('name');
            }
            
            // Validate email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                document.getElementById('contact-email-error').textContent = 'Valid email is required';
                errors.push('email');
            }
            
            // Validate subject
            if (!subject) {
                document.getElementById('contact-subject-error').textContent = 'Please select a subject';
                errors.push('subject');
            }
            
            // Validate message
            if (!message || message.length < 10) {
                document.getElementById('contact-message-error').textContent = 'Message must be at least 10 characters';
                errors.push('message');
            }
            
            // Show result
            if (errors.length === 0) {
                contactResult.innerHTML = `
                    <h3>✅ Message Sent Successfully!</h3>
                    <p>Thank you for contacting us, ${name}!</p>
                    <p>We'll respond to ${email} within 24 hours.</p>
                `;
                contactResult.className = 'form-result success show';
                contactForm.reset();
                charCount.textContent = '0';
            } else {
                contactResult.innerHTML = `
                    <h3>❌ Form Validation Failed</h3>
                    <p>Please fix the ${errors.length} error(s) highlighted above.</p>
                `;
                contactResult.className = 'form-result error show';
            }
        });
    }
    
    // Add visual feedback for all buttons
    document.querySelectorAll('.demo-btn, .nav-btn').forEach(btn => {
        btn.addEventListener('mousedown', function() {
            this.style.transform = 'scale(0.95)';
        });
        
        btn.addEventListener('mouseup', function() {
            this.style.transform = 'scale(1)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
});

// Utility functions
function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

function sanitizeInput(input) {
    const div = document.createElement('div');
    div.textContent = input;
    return div.innerHTML;
}

// Make functions globally available
window.validationUtils = {
    validateEmail,
    sanitizeInput
};
