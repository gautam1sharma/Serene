// Topic 2: Asynchronous JavaScript & Promises - Interactive Script

document.addEventListener('DOMContentLoaded', function() {
    
    // ===== FLOATING OBJECTS INTERACTION (Slide 1) =====
    const floatingObjects = document.querySelectorAll('.floating-object');
    let draggedElement = null;
    let offsetX = 0;
    let offsetY = 0;
    let isDragging = false;
    
    floatingObjects.forEach(obj => {
        // Mouse down to start dragging
        obj.addEventListener('mousedown', function(e) {
            if (e.button === 0) { // Left click only
                isDragging = true;
                draggedElement = this;
                this.classList.add('dragging');
                
                const rect = this.getBoundingClientRect();
                offsetX = e.clientX - rect.left - rect.width / 2;
                offsetY = e.clientY - rect.top - rect.height / 2;
                
                // Pause animation while dragging
                this.style.animationPlayState = 'paused';
                
                e.preventDefault();
            }
        });
        
        // Touch start for mobile
        obj.addEventListener('touchstart', function(e) {
            isDragging = true;
            draggedElement = this;
            this.classList.add('dragging');
            
            const touch = e.touches[0];
            const rect = this.getBoundingClientRect();
            offsetX = touch.clientX - rect.left - rect.width / 2;
            offsetY = touch.clientY - rect.top - rect.height / 2;
            
            this.style.animationPlayState = 'paused';
            
            e.preventDefault();
        }, { passive: false });
        
        // Hover effect
        obj.addEventListener('mouseenter', function() {
            if (!isDragging) {
                this.style.animationPlayState = 'paused';
            }
        });
        
        obj.addEventListener('mouseleave', function() {
            if (!isDragging) {
                this.style.animationPlayState = 'running';
            }
        });
    });
    
    // Mouse move for smooth dragging
    document.addEventListener('mousemove', function(e) {
        if (isDragging && draggedElement) {
            const container = draggedElement.parentElement;
            const containerRect = container.getBoundingClientRect();
            const objRect = draggedElement.getBoundingClientRect();
            
            let newX = e.clientX - containerRect.left - offsetX - objRect.width / 2;
            let newY = e.clientY - containerRect.top - offsetY - objRect.height / 2;
            
            // Constrain within container with padding
            const padding = 10;
            newX = Math.max(padding, Math.min(newX, containerRect.width - objRect.width - padding));
            newY = Math.max(padding, Math.min(newY, containerRect.height - objRect.height - padding));
            
            // Use transform for smoother animation
            draggedElement.style.left = newX + 'px';
            draggedElement.style.top = newY + 'px';
            draggedElement.style.transform = 'scale(1.1)';
        }
    });
    
    // Touch move for mobile
    document.addEventListener('touchmove', function(e) {
        if (isDragging && draggedElement) {
            const touch = e.touches[0];
            const container = draggedElement.parentElement;
            const containerRect = container.getBoundingClientRect();
            const objRect = draggedElement.getBoundingClientRect();
            
            let newX = touch.clientX - containerRect.left - offsetX - objRect.width / 2;
            let newY = touch.clientY - containerRect.top - offsetY - objRect.height / 2;
            
            const padding = 10;
            newX = Math.max(padding, Math.min(newX, containerRect.width - objRect.width - padding));
            newY = Math.max(padding, Math.min(newY, containerRect.height - objRect.height - padding));
            
            draggedElement.style.left = newX + 'px';
            draggedElement.style.top = newY + 'px';
            draggedElement.style.transform = 'scale(1.1)';
            
            e.preventDefault();
        }
    }, { passive: false });
    
    // Mouse up to stop dragging
    document.addEventListener('mouseup', function(e) {
        if (isDragging && draggedElement) {
            draggedElement.classList.remove('dragging');
            draggedElement.style.animationPlayState = 'running';
            draggedElement.style.transform = '';
            draggedElement = null;
            isDragging = false;
        }
    });
    
    // Touch end for mobile
    document.addEventListener('touchend', function(e) {
        if (isDragging && draggedElement) {
            draggedElement.classList.remove('dragging');
            draggedElement.style.animationPlayState = 'running';
            draggedElement.style.transform = '';
            draggedElement = null;
            isDragging = false;
        }
    });
    
    // Theme Toggle (same as Topic 1)
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;
    const logoDark = document.getElementById('logo-dark');
    const logoLight = document.getElementById('logo-light');
    
    const currentTheme = localStorage.getItem('theme') || 'dark';
    if (currentTheme === 'light') {
        body.classList.add('light-theme');
        if (logoDark && logoLight) {
            logoDark.style.display = 'none';
            logoLight.style.display = 'block';
        }
    }
    
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            body.classList.toggle('light-theme');
            
            if (logoDark && logoLight) {
                if (body.classList.contains('light-theme')) {
                    logoDark.style.display = 'none';
                    logoLight.style.display = 'block';
                } else {
                    logoDark.style.display = 'block';
                    logoLight.style.display = 'none';
                }
            }
            
            const theme = body.classList.contains('light-theme') ? 'light' : 'dark';
            localStorage.setItem('theme', theme);
            
            this.style.transform = 'scale(0.9)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    }
    
    // Slide Navigation
    let currentSlide = 1;
    const totalSlides = 14;
    
    function updateSlideCounter() {
        document.getElementById('current-slide').textContent = currentSlide;
        document.getElementById('total-slides').textContent = totalSlides;
    }

    
    function showSlide(slideNumber) {
        document.querySelectorAll('.slide').forEach(slide => {
            slide.classList.remove('active');
        });
        
        const targetSlide = document.querySelector(`[data-slide="${slideNumber}"]`);
        if (targetSlide) {
            targetSlide.classList.add('active');
            currentSlide = slideNumber;
            updateSlideCounter();
            
            document.getElementById('prev-btn').disabled = currentSlide === 1;
            document.getElementById('next-btn').disabled = currentSlide === totalSlides;
        }
    }
    
    document.getElementById('prev-btn').addEventListener('click', function() {
        if (currentSlide > 1) {
            showSlide(currentSlide - 1);
        }
    });
    
    document.getElementById('next-btn').addEventListener('click', function() {
        if (currentSlide < totalSlides) {
            showSlide(currentSlide + 1);
        }
    });
    
    document.addEventListener('keydown', function(event) {
        if (event.key === 'ArrowLeft' && currentSlide > 1) {
            showSlide(currentSlide - 1);
        } else if (event.key === 'ArrowRight' && currentSlide < totalSlides) {
            showSlide(currentSlide + 1);
        }
    });
    
    // Touch/Swipe navigation
    let touchStartX = 0;
    let touchEndX = 0;
    
    const slidesContainer = document.querySelector('.slides-container');
    if (slidesContainer) {
        slidesContainer.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });
        
        slidesContainer.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        }, { passive: true });
        
        function handleSwipe() {
            const swipeThreshold = 50;
            const diff = touchStartX - touchEndX;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0 && currentSlide < totalSlides) {
                    showSlide(currentSlide + 1);
                } else if (diff < 0 && currentSlide > 1) {
                    showSlide(currentSlide - 1);
                }
            }
        }
    }
    
    updateSlideCounter();

    // ===== SLIDE 2: DOM Manipulation Demo =====
    const changeTextBtn = document.getElementById('change-text-btn');
    const changeColorBtn = document.getElementById('change-color-btn');
    const addElementBtn = document.getElementById('add-element-btn');
    const removeElementBtn = document.getElementById('remove-element-btn');
    const demoHeading = document.getElementById('demo-heading');
    const demoParagraph = document.getElementById('demo-paragraph');
    const dynamicContainer = document.getElementById('dynamic-container');
    const domExplanation = document.getElementById('dom-explanation');
    
    const texts = [
        'Hello, DOM!',
        'DOM Manipulation is Powerful!',
        'JavaScript Controls Everything!',
        'Dynamic Content is Amazing!',
        'Welcome to Modern Web Development!'
    ];
    let textIndex = 0;
    
    const colors = ['#3498db', '#e74c3c', '#27ae60', '#f39c12', '#9b59b6', '#1abc9c'];
    let colorIndex = 0;
    
    let elementCounter = 0;
    
    if (changeTextBtn) {
        changeTextBtn.addEventListener('click', function() {
            textIndex = (textIndex + 1) % texts.length;
            demoHeading.textContent = texts[textIndex];
            
            domExplanation.innerHTML = `<strong>Code executed:</strong><br>
demoHeading.textContent = '${texts[textIndex]}';`;
            
            demoHeading.style.transform = 'scale(1.1)';
            setTimeout(() => {
                demoHeading.style.transform = 'scale(1)';
            }, 200);
        });
    }
    
    if (changeColorBtn) {
        changeColorBtn.addEventListener('click', function() {
            colorIndex = (colorIndex + 1) % colors.length;
            demoParagraph.style.color = colors[colorIndex];
            
            domExplanation.innerHTML = `<strong>Code executed:</strong><br>
demoParagraph.style.color = '${colors[colorIndex]}';`;
            
            demoParagraph.style.transform = 'scale(1.05)';
            setTimeout(() => {
                demoParagraph.style.transform = 'scale(1)';
            }, 200);
        });
    }
    
    if (addElementBtn) {
        addElementBtn.addEventListener('click', function() {
            elementCounter++;
            const newElement = document.createElement('div');
            newElement.className = 'dynamic-item';
            newElement.innerHTML = `
                <span>Dynamic Element #${elementCounter}</span>
                <span>Created at ${new Date().toLocaleTimeString()}</span>
            `;
            dynamicContainer.appendChild(newElement);
            
            domExplanation.innerHTML = `<strong>Code executed:</strong><br>
const newElement = document.createElement('div');<br>
newElement.className = 'dynamic-item';<br>
newElement.innerHTML = '...';<br>
dynamicContainer.appendChild(newElement);`;
        });
    }
    
    if (removeElementBtn) {
        removeElementBtn.addEventListener('click', function() {
            const lastElement = dynamicContainer.lastElementChild;
            if (lastElement) {
                lastElement.style.animation = 'fadeOut 0.3s ease-out';
                setTimeout(() => {
                    dynamicContainer.removeChild(lastElement);
                }, 300);
                
                domExplanation.innerHTML = `<strong>Code executed:</strong><br>
const lastElement = dynamicContainer.lastElementChild;<br>
dynamicContainer.removeChild(lastElement);`;
            } else {
                domExplanation.innerHTML = `<strong>No elements to remove!</strong><br>
The container is empty. Add some elements first.`;
            }
        });
    }
    
    // ===== SLIDE 3: Synchronous vs Asynchronous Demo =====
    const syncDemoBtn = document.getElementById('sync-demo-btn');
    const asyncDemoBtn = document.getElementById('async-demo-btn');
    const executionLog = document.getElementById('execution-log');
    const visualTimeline = document.getElementById('visual-timeline');
    
    function logExecution(message, type = 'sync') {
        if (executionLog) {
            const timestamp = new Date().toLocaleTimeString();
            const logClass = type === 'async' ? 'log-async' : 'log-sync';
            executionLog.innerHTML += `<div class="log-entry ${logClass}">[${timestamp}] ${message}</div>`;
            executionLog.scrollTop = executionLog.scrollHeight;
        }
    }
    
    function addTimelineBlock(text, type) {
        if (visualTimeline) {
            const block = document.createElement('div');
            block.className = `timeline-block ${type}`;
            block.textContent = text;
            visualTimeline.appendChild(block);
        }
    }
    
    if (syncDemoBtn) {
        syncDemoBtn.addEventListener('click', function() {
            executionLog.innerHTML = '';
            visualTimeline.innerHTML = '';
            
            logExecution('First - Synchronous', 'sync');
            addTimelineBlock('First', 'sync');
            
            setTimeout(() => {
                logExecution('Second - Synchronous', 'sync');
                addTimelineBlock('Second', 'sync');
            }, 500);
            
            setTimeout(() => {
                logExecution('Third - Synchronous', 'sync');
                addTimelineBlock('Third', 'sync');
            }, 1000);
        });
    }
    
    if (asyncDemoBtn) {
        asyncDemoBtn.addEventListener('click', function() {
            executionLog.innerHTML = '';
            visualTimeline.innerHTML = '';
            
            logExecution('First - Executed immediately', 'sync');
            addTimelineBlock('First', 'sync');
            
            setTimeout(() => {
                logExecution('Second - Async (after 1s)', 'async');
                addTimelineBlock('Second', 'async');
            }, 1000);
            
            setTimeout(() => {
                logExecution('Third - Executed immediately', 'sync');
                addTimelineBlock('Third', 'sync');
            }, 100);
        });
    }

    
    // ===== SLIDE 3: Coffee Shop Callback Demo =====
    const orderCoffeeBtn = document.getElementById('order-coffee-btn');
    const coffeeStatus = document.getElementById('coffee-status');
    const coffeeResult = document.getElementById('coffee-result');
    
    function takeOrder(callback) {
        const statusOrder = document.getElementById('status-order');
        statusOrder.classList.add('active');
        statusOrder.textContent = '📝 Taking your order...';
        
        setTimeout(() => {
            statusOrder.classList.remove('active');
            statusOrder.classList.add('completed');
            statusOrder.textContent = '📝 Order received!';
            callback('Cappuccino');
        }, 1500);
    }
    
    function brewCoffee(coffeeType, callback) {
        const statusBrew = document.getElementById('status-brew');
        statusBrew.classList.add('active');
        statusBrew.textContent = `☕ Brewing your ${coffeeType}...`;
        
        setTimeout(() => {
            statusBrew.classList.remove('active');
            statusBrew.classList.add('completed');
            statusBrew.textContent = `☕ ${coffeeType} brewed!`;
            callback(coffeeType);
        }, 2000);
    }
    
    function serveCoffee(coffeeType, callback) {
        const statusServe = document.getElementById('status-serve');
        statusServe.classList.add('active');
        statusServe.textContent = `🎁 Preparing to serve...`;
        
        setTimeout(() => {
            statusServe.classList.remove('active');
            statusServe.classList.add('completed');
            statusServe.textContent = `🎁 ${coffeeType} served!`;
            callback(coffeeType);
        }, 1000);
    }
    
    if (orderCoffeeBtn) {
        orderCoffeeBtn.addEventListener('click', function() {
            // Reset status
            document.querySelectorAll('.status-item').forEach(item => {
                item.classList.remove('active', 'completed');
                item.textContent = item.textContent.split('...')[0] + '...';
            });
            coffeeResult.classList.remove('show');
            coffeeResult.textContent = '';
            
            // Callback chain
            takeOrder(function(order) {
                brewCoffee(order, function(coffee) {
                    serveCoffee(coffee, function(finalCoffee) {
                        coffeeResult.textContent = `☕ Enjoy your ${finalCoffee}! ☕`;
                        coffeeResult.classList.add('show');
                    });
                });
            });
        });
    }

    
    // ===== SLIDE 4: Promise State Visualizer =====
    const createPromiseBtn = document.getElementById('create-promise-btn');
    const resolvePromiseBtn = document.getElementById('resolve-promise-btn');
    const rejectPromiseBtn = document.getElementById('reject-promise-btn');
    const promiseResult = document.getElementById('promise-result');
    
    let currentPromise = null;
    let promiseResolver = null;
    let promiseRejecter = null;
    
    function resetPromiseState() {
        document.querySelectorAll('.state-box').forEach(box => {
            box.classList.remove('active');
        });
    }
    
    if (createPromiseBtn) {
        createPromiseBtn.addEventListener('click', function() {
            resetPromiseState();
            promiseResult.textContent = 'Promise created! Click Resolve or Reject.';
            
            document.querySelector('.state-box.pending').classList.add('active');
            
            currentPromise = new Promise((resolve, reject) => {
                promiseResolver = resolve;
                promiseRejecter = reject;
            });
            
            resolvePromiseBtn.disabled = false;
            rejectPromiseBtn.disabled = false;
        });
    }
    
    if (resolvePromiseBtn) {
        resolvePromiseBtn.addEventListener('click', function() {
            if (promiseResolver) {
                resetPromiseState();
                document.querySelector('.state-box.fulfilled').classList.add('active');
                promiseResolver('Success! Promise fulfilled.');
                
                currentPromise.then(result => {
                    promiseResult.textContent = `✅ ${result}`;
                });
                
                this.disabled = true;
                rejectPromiseBtn.disabled = true;
            }
        });
    }
    
    if (rejectPromiseBtn) {
        rejectPromiseBtn.addEventListener('click', function() {
            if (promiseRejecter) {
                resetPromiseState();
                document.querySelector('.state-box.rejected').classList.add('active');
                promiseRejecter('Error! Promise rejected.');
                
                currentPromise.catch(error => {
                    promiseResult.textContent = `❌ ${error}`;
                });
                
                this.disabled = true;
                resolvePromiseBtn.disabled = true;
            }
        });
    }

    
    // ===== SLIDE 5: Pizza Delivery Chain =====
    const orderPizzaBtn = document.getElementById('order-pizza-btn');
    const pizzaResult = document.getElementById('pizza-result');
    
    function placeOrder() {
        return new Promise((resolve) => {
            const step = document.getElementById('step-order');
            step.classList.add('active');
            step.querySelector('.step-status').textContent = 'Placing order...';
            
            setTimeout(() => {
                step.classList.remove('active');
                step.classList.add('completed');
                step.querySelector('.step-status').textContent = 'Order placed!';
                resolve('Order #12345');
            }, 1500);
        });
    }
    
    function preparePizza(orderId) {
        return new Promise((resolve) => {
            const step = document.getElementById('step-prepare');
            step.classList.add('active');
            step.querySelector('.step-status').textContent = 'Preparing...';
            
            setTimeout(() => {
                step.classList.remove('active');
                step.classList.add('completed');
                step.querySelector('.step-status').textContent = 'Prepared!';
                resolve(`${orderId} - Prepared`);
            }, 2000);
        });
    }
    
    function bakePizza(orderId) {
        return new Promise((resolve) => {
            const step = document.getElementById('step-bake');
            step.classList.add('active');
            step.querySelector('.step-status').textContent = 'Baking...';
            
            setTimeout(() => {
                step.classList.remove('active');
                step.classList.add('completed');
                step.querySelector('.step-status').textContent = 'Baked!';
                resolve(`${orderId} - Baked`);
            }, 2500);
        });
    }
    
    function deliverPizza(orderId) {
        return new Promise((resolve) => {
            const step = document.getElementById('step-deliver');
            step.classList.add('active');
            step.querySelector('.step-status').textContent = 'Delivering...';
            
            setTimeout(() => {
                step.classList.remove('active');
                step.classList.add('completed');
                step.querySelector('.step-status').textContent = 'Delivered!';
                resolve(`${orderId} - Delivered`);
            }, 1500);
        });
    }
    
    if (orderPizzaBtn) {
        orderPizzaBtn.addEventListener('click', function() {
            // Reset all steps
            document.querySelectorAll('.chain-step').forEach(step => {
                step.classList.remove('active', 'completed');
                step.querySelector('.step-status').textContent = 'Waiting...';
            });
            pizzaResult.classList.remove('show');
            
            // Promise chain
            placeOrder()
                .then(orderId => preparePizza(orderId))
                .then(orderId => bakePizza(orderId))
                .then(orderId => deliverPizza(orderId))
                .then(result => {
                    pizzaResult.textContent = `🍕 ${result}! Enjoy your pizza! 🍕`;
                    pizzaResult.classList.add('show');
                })
                .catch(error => {
                    pizzaResult.textContent = `❌ Error: ${error}`;
                    pizzaResult.classList.add('show');
                });
        });
    }

    
    // ===== SLIDE 6: Race Simulation =====
    const startRaceBtn = document.getElementById('start-race-btn');
    const raceResult = document.getElementById('race-result');
    
    function runRace(runnerId, duration) {
        return new Promise((resolve) => {
            const progressBar = document.getElementById(`progress-${runnerId}`);
            let progress = 0;
            const interval = 50;
            const increment = (100 / duration) * interval;
            
            const timer = setInterval(() => {
                progress += increment;
                if (progress >= 100) {
                    progress = 100;
                    clearInterval(timer);
                    resolve(`Runner ${runnerId}`);
                }
                progressBar.style.width = progress + '%';
            }, interval);
        });
    }
    
    if (startRaceBtn) {
        startRaceBtn.addEventListener('click', function() {
            // Reset progress bars
            for (let i = 1; i <= 3; i++) {
                document.getElementById(`progress-${i}`).style.width = '0%';
            }
            raceResult.classList.remove('show');
            
            // Random durations for each runner
            const duration1 = 2000 + Math.random() * 2000;
            const duration2 = 2000 + Math.random() * 2000;
            const duration3 = 2000 + Math.random() * 2000;
            
            // Promise.race - first to finish wins
            Promise.race([
                runRace(1, duration1),
                runRace(2, duration2),
                runRace(3, duration3)
            ]).then(winner => {
                raceResult.textContent = `🏆 ${winner} wins the race! 🏆`;
                raceResult.classList.add('show');
            });
        });
    }

    
    // ===== SLIDE 7: ATM Withdrawal =====
    const withdrawBtn = document.getElementById('withdraw-btn');
    const withdrawAmount = document.getElementById('withdraw-amount');
    const balanceDisplay = document.getElementById('balance');
    const atmLog = document.getElementById('atm-log');
    
    let balance = 1000;
    
    function logATM(message, type = 'info') {
        if (atmLog) {
            const timestamp = new Date().toLocaleTimeString();
            const color = type === 'error' ? '#e74c3c' : type === 'success' ? '#27ae60' : '#3498db';
            atmLog.innerHTML += `<div style="color: ${color}">[${timestamp}] ${message}</div>`;
            atmLog.scrollTop = atmLog.scrollHeight;
        }
    }
    
    async function checkBalance() {
        logATM('Checking balance...');
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(balance);
            }, 500);
        });
    }
    
    async function validateAmount(amount) {
        logATM('Validating amount...');
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (amount <= 0) {
                    reject('Amount must be greater than 0');
                } else if (amount > balance) {
                    reject('Insufficient funds');
                } else if (amount % 10 !== 0) {
                    reject('Amount must be multiple of 10');
                } else {
                    resolve(true);
                }
            }, 500);
        });
    }
    
    async function dispenseCash(amount) {
        logATM('Dispensing cash...');
        return new Promise((resolve) => {
            setTimeout(() => {
                balance -= amount;
                resolve(amount);
            }, 1000);
        });
    }
    
    if (withdrawBtn) {
        withdrawBtn.addEventListener('click', async function() {
            const amount = parseInt(withdrawAmount.value);
            atmLog.innerHTML = '';
            
            try {
                logATM('Starting withdrawal process...');
                
                const currentBalance = await checkBalance();
                logATM(`Current balance: $${currentBalance}`, 'info');
                
                await validateAmount(amount);
                logATM('Amount validated', 'success');
                
                const dispensed = await dispenseCash(amount);
                logATM(`Successfully dispensed $${dispensed}`, 'success');
                
                balanceDisplay.textContent = balance;
                logATM(`New balance: $${balance}`, 'success');
                
                withdrawAmount.value = '';
            } catch (error) {
                logATM(`Error: ${error}`, 'error');
            }
        });
    }

    
    // ===== SLIDE 8: Login System with Error Handling =====
    const loginBtn = document.getElementById('login-btn');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginStatus = document.getElementById('login-status');
    
    async function authenticateUser(username, password) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (username === 'admin' && password === 'password123') {
                    resolve({ username, role: 'admin', token: 'abc123xyz' });
                } else if (!username || !password) {
                    reject(new Error('Username and password are required'));
                } else {
                    reject(new Error('Invalid credentials'));
                }
            }, 1500);
        });
    }
    
    if (loginBtn) {
        loginBtn.addEventListener('click', async function() {
            const username = usernameInput.value.trim();
            const password = passwordInput.value.trim();
            
            loginStatus.className = 'login-status loading';
            loginStatus.textContent = '🔄 Authenticating...';
            
            try {
                const user = await authenticateUser(username, password);
                
                loginStatus.className = 'login-status success';
                loginStatus.textContent = `✅ Welcome back, ${user.username}! Login successful.`;
                
                usernameInput.value = '';
                passwordInput.value = '';
            } catch (error) {
                loginStatus.className = 'login-status error';
                loginStatus.textContent = `❌ ${error.message}`;
            }
        });
        
        // Allow Enter key to submit
        [usernameInput, passwordInput].forEach(input => {
            if (input) {
                input.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        loginBtn.click();
                    }
                });
            }
        });
    }

    
    // ===== SLIDE 9: Real API Integration - User Directory =====
    const fetchUsersBtn = document.getElementById('fetch-users-btn');
    const clearUsersBtn = document.getElementById('clear-users-btn');
    const usersContainer = document.getElementById('users-container');
    const loadingSpinner = document.getElementById('loading-spinner');
    const usersList = document.getElementById('users-list');
    
    async function fetchUsers() {
        try {
            const response = await fetch('https://jsonplaceholder.typicode.com/users');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const users = await response.json();
            return users;
        } catch (error) {
            console.error('Error fetching users:', error);
            throw error;
        }
    }
    
    function displayUsers(users) {
        usersList.innerHTML = '';
        users.forEach(user => {
            const userCard = document.createElement('div');
            userCard.className = 'user-card';
            userCard.innerHTML = `
                <h4>${user.name}</h4>
                <p>📧 ${user.email}</p>
                <p>📱 ${user.phone}</p>
                <p>🏢 ${user.company.name}</p>
                <p>🌐 ${user.website}</p>
            `;
            usersList.appendChild(userCard);
        });
    }
    
    if (fetchUsersBtn) {
        fetchUsersBtn.addEventListener('click', async function() {
            loadingSpinner.style.display = 'block';
            usersList.innerHTML = '';
            
            try {
                const users = await fetchUsers();
                loadingSpinner.style.display = 'none';
                displayUsers(users);
            } catch (error) {
                loadingSpinner.style.display = 'none';
                usersList.innerHTML = `<div style="color: #e74c3c; text-align: center; padding: 40px;">
                    ❌ Failed to load users: ${error.message}
                </div>`;
            }
        });
    }
    
    if (clearUsersBtn) {
        clearUsersBtn.addEventListener('click', function() {
            usersList.innerHTML = '';
            loadingSpinner.style.display = 'none';
        });
    }

    
    // ===== SLIDE 10: Parallel vs Sequential Downloads =====
    const sequentialDownloadBtn = document.getElementById('sequential-download-btn');
    const parallelDownloadBtn = document.getElementById('parallel-download-btn');
    const downloadTime = document.getElementById('download-time');
    
    function downloadFile(fileId, duration) {
        return new Promise((resolve) => {
            const progressBar = document.getElementById(`file${fileId}-progress`);
            const statusElement = document.getElementById(`file${fileId}-status`);
            
            statusElement.textContent = 'Downloading...';
            statusElement.className = 'file-status downloading';
            
            let progress = 0;
            const interval = 50;
            const increment = (100 / duration) * interval;
            
            const timer = setInterval(() => {
                progress += increment;
                if (progress >= 100) {
                    progress = 100;
                    clearInterval(timer);
                    statusElement.textContent = 'Completed';
                    statusElement.className = 'file-status completed';
                    resolve(`file${fileId}.pdf`);
                }
                progressBar.style.width = progress + '%';
            }, interval);
        });
    }
    
    function resetDownloads() {
        for (let i = 1; i <= 3; i++) {
            document.getElementById(`file${i}-progress`).style.width = '0%';
            document.getElementById(`file${i}-status`).textContent = 'Ready';
            document.getElementById(`file${i}-status`).className = 'file-status';
        }
        downloadTime.classList.remove('show');
    }
    
    if (sequentialDownloadBtn) {
        sequentialDownloadBtn.addEventListener('click', async function() {
            resetDownloads();
            const startTime = Date.now();
            
            // Sequential - one after another
            await downloadFile(1, 2000);
            await downloadFile(2, 2000);
            await downloadFile(3, 2000);
            
            const totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
            downloadTime.textContent = `⏱️ Sequential Download: ${totalTime} seconds`;
            downloadTime.classList.add('show');
        });
    }
    
    if (parallelDownloadBtn) {
        parallelDownloadBtn.addEventListener('click', async function() {
            resetDownloads();
            const startTime = Date.now();
            
            // Parallel - all at once
            await Promise.all([
                downloadFile(1, 2000),
                downloadFile(2, 2000),
                downloadFile(3, 2000)
            ]);
            
            const totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
            downloadTime.textContent = `⚡ Parallel Download: ${totalTime} seconds (Much faster!)`;
            downloadTime.classList.add('show');
        });
    }

    
    // ===== SLIDE 11: Search with Debounce =====
    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');
    const requestCount = document.getElementById('request-count');
    const lastSearch = document.getElementById('last-search');
    
    let requestCounter = 0;
    let searchTimeout;
    
    // Mock search function
    async function searchUsers(query) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const mockUsers = [
                    'Alice Johnson', 'Bob Smith', 'Charlie Brown',
                    'David Wilson', 'Emma Davis', 'Frank Miller',
                    'Grace Lee', 'Henry Taylor', 'Ivy Anderson'
                ];
                
                const results = mockUsers.filter(name => 
                    name.toLowerCase().includes(query.toLowerCase())
                );
                
                resolve(results);
            }, 500);
        });
    }
    
    function debounce(func, delay) {
        return function(...args) {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                func.apply(this, args);
            }, delay);
        };
    }
    
    async function performSearch(query) {
        if (!query.trim()) {
            searchResults.innerHTML = '<div style="color: #7a7a9a; text-align: center; padding: 40px;">Type to search...</div>';
            return;
        }
        
        requestCounter++;
        requestCount.textContent = requestCounter;
        lastSearch.textContent = query;
        
        searchResults.innerHTML = '<div style="color: #f39c12; text-align: center; padding: 40px;">🔍 Searching...</div>';
        
        try {
            const results = await searchUsers(query);
            
            if (results.length === 0) {
                searchResults.innerHTML = '<div style="color: #7a7a9a; text-align: center; padding: 40px;">No results found</div>';
            } else {
                searchResults.innerHTML = results.map(name => `
                    <div class="search-result-item">
                        👤 ${name}
                    </div>
                `).join('');
            }
        } catch (error) {
            searchResults.innerHTML = `<div style="color: #e74c3c; text-align: center; padding: 40px;">Error: ${error.message}</div>`;
        }
    }
    
    if (searchInput) {
        const debouncedSearch = debounce(performSearch, 500);
        
        searchInput.addEventListener('input', function() {
            debouncedSearch(this.value);
        });
    }

    
    // ===== SLIDE 13: Weather App Practice =====
    const getWeatherBtn = document.getElementById('get-weather-btn');
    const cityInput = document.getElementById('city-input');
    const weatherDisplay = document.getElementById('weather-display');
    
    // Mock weather API (since we can't use real API keys in demo)
    async function fetchWeather(city) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                const mockWeatherData = {
                    'london': { temp: 15, description: 'Cloudy', humidity: 65, windSpeed: 12 },
                    'paris': { temp: 18, description: 'Partly Cloudy', humidity: 55, windSpeed: 8 },
                    'tokyo': { temp: 22, description: 'Sunny', humidity: 45, windSpeed: 10 },
                    'new york': { temp: 20, description: 'Clear Sky', humidity: 50, windSpeed: 15 },
                    'seoul': { temp: 16, description: 'Rainy', humidity: 75, windSpeed: 18 },
                    'mumbai': { temp: 30, description: 'Hot and Humid', humidity: 80, windSpeed: 5 },
                    'sydney': { temp: 25, description: 'Sunny', humidity: 40, windSpeed: 14 },
                    'chennai': { temp: 32, description: 'Hot and Sunny', humidity: 70, windSpeed: 8 }
                };
                
                const cityLower = city.toLowerCase();
                if (mockWeatherData[cityLower]) {
                    resolve({
                        city: city,
                        ...mockWeatherData[cityLower]
                    });
                } else {
                    reject(new Error('City not found. Try: London, Paris, Tokyo, New York, Seoul, Mumbai, Chennai, or Sydney'));
                }
            }, 1000);
        });
    }
    
    if (getWeatherBtn) {
        getWeatherBtn.addEventListener('click', async function() {
            const city = cityInput.value.trim();
            
            if (!city) {
                weatherDisplay.innerHTML = '<div class="weather-placeholder">Please enter a city name</div>';
                return;
            }
            
            weatherDisplay.innerHTML = `
                <div class="loading-spinner">
                    <div class="spinner"></div>
                    <p>Loading weather data...</p>
                </div>
            `;
            
            try {
                const weather = await fetchWeather(city);
                
                weatherDisplay.innerHTML = `
                    <div class="weather-data">
                        <div class="weather-city">${weather.city}</div>
                        <div class="weather-temp">${weather.temp}°C</div>
                        <div class="weather-description">${weather.description}</div>
                        <div class="weather-details">
                            <div class="weather-detail">
                                <div class="weather-detail-label">Humidity</div>
                                <div class="weather-detail-value">${weather.humidity}%</div>
                            </div>
                            <div class="weather-detail">
                                <div class="weather-detail-label">Wind Speed</div>
                                <div class="weather-detail-value">${weather.windSpeed} km/h</div>
                            </div>
                        </div>
                    </div>
                `;
                
                cityInput.value = '';
            } catch (error) {
                weatherDisplay.innerHTML = `
                    <div style="color: #e74c3c; padding: 40px; text-align: center;">
                        <div style="font-size: 3em; margin-bottom: 20px;">❌</div>
                        <div style="font-size: 1.2em; font-weight: 600; margin-bottom: 10px;">Error</div>
                        <div>${error.message}</div>
                    </div>
                `;
            }
        });
        
        // Allow Enter key to submit
        if (cityInput) {
            cityInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    getWeatherBtn.click();
                }
            });
        }
    }
    
    // Add visual feedback for all buttons
    document.querySelectorAll('.demo-btn, .nav-btn').forEach(btn => {
        btn.addEventListener('mousedown', function() {
            this.style.transform = 'scale(0.95)';
        });
        
        btn.addEventListener('mouseup', function() {
            this.style.transform = 'scale(1)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
});

// Utility functions
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Make some functions globally available
window.asyncDemoFunctions = {
    sleep
};
