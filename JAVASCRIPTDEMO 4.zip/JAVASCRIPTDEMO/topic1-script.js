// Topic 1: JavaScript Events & User Interaction Handling - Interactive Script

document.addEventListener('DOMContentLoaded', function() {
    
    // ===== FLOATING OBJECTS INTERACTION (Slide 1) =====
    const floatingObjects = document.querySelectorAll('.floating-object');
    let draggedElement = null;
    let offsetX = 0;
    let offsetY = 0;
    let isDragging = false;
    
    floatingObjects.forEach(obj => {
        // Mouse down to start dragging
        obj.addEventListener('mousedown', function(e) {
            if (e.button === 0) { // Left click only
                isDragging = true;
                draggedElement = this;
                this.classList.add('dragging');
                
                const rect = this.getBoundingClientRect();
                offsetX = e.clientX - rect.left - rect.width / 2;
                offsetY = e.clientY - rect.top - rect.height / 2;
                
                // Pause animation while dragging
                this.style.animationPlayState = 'paused';
                
                e.preventDefault();
            }
        });
        
        // Touch start for mobile
        obj.addEventListener('touchstart', function(e) {
            isDragging = true;
            draggedElement = this;
            this.classList.add('dragging');
            
            const touch = e.touches[0];
            const rect = this.getBoundingClientRect();
            offsetX = touch.clientX - rect.left - rect.width / 2;
            offsetY = touch.clientY - rect.top - rect.height / 2;
            
            this.style.animationPlayState = 'paused';
            
            e.preventDefault();
        }, { passive: false });
        
        // Hover effect
        obj.addEventListener('mouseenter', function() {
            if (!isDragging) {
                this.style.animationPlayState = 'paused';
            }
        });
        
        obj.addEventListener('mouseleave', function() {
            if (!isDragging) {
                this.style.animationPlayState = 'running';
            }
        });
    });
    
    // Mouse move for smooth dragging
    document.addEventListener('mousemove', function(e) {
        if (isDragging && draggedElement) {
            const container = draggedElement.parentElement;
            const containerRect = container.getBoundingClientRect();
            const objRect = draggedElement.getBoundingClientRect();
            
            let newX = e.clientX - containerRect.left - offsetX - objRect.width / 2;
            let newY = e.clientY - containerRect.top - offsetY - objRect.height / 2;
            
            // Constrain within container with padding
            const padding = 10;
            newX = Math.max(padding, Math.min(newX, containerRect.width - objRect.width - padding));
            newY = Math.max(padding, Math.min(newY, containerRect.height - objRect.height - padding));
            
            // Use transform for smoother animation
            draggedElement.style.left = newX + 'px';
            draggedElement.style.top = newY + 'px';
            draggedElement.style.transform = 'scale(1.1)';
        }
    });
    
    // Touch move for mobile
    document.addEventListener('touchmove', function(e) {
        if (isDragging && draggedElement) {
            const touch = e.touches[0];
            const container = draggedElement.parentElement;
            const containerRect = container.getBoundingClientRect();
            const objRect = draggedElement.getBoundingClientRect();
            
            let newX = touch.clientX - containerRect.left - offsetX - objRect.width / 2;
            let newY = touch.clientY - containerRect.top - offsetY - objRect.height / 2;
            
            const padding = 10;
            newX = Math.max(padding, Math.min(newX, containerRect.width - objRect.width - padding));
            newY = Math.max(padding, Math.min(newY, containerRect.height - objRect.height - padding));
            
            draggedElement.style.left = newX + 'px';
            draggedElement.style.top = newY + 'px';
            draggedElement.style.transform = 'scale(1.1)';
            
            e.preventDefault();
        }
    }, { passive: false });
    
    // Mouse up to stop dragging
    document.addEventListener('mouseup', function(e) {
        if (isDragging && draggedElement) {
            draggedElement.classList.remove('dragging');
            draggedElement.style.animationPlayState = 'running';
            draggedElement.style.transform = '';
            draggedElement = null;
            isDragging = false;
        }
    });
    
    // Touch end for mobile
    document.addEventListener('touchend', function(e) {
        if (isDragging && draggedElement) {
            draggedElement.classList.remove('dragging');
            draggedElement.style.animationPlayState = 'running';
            draggedElement.style.transform = '';
            draggedElement = null;
            isDragging = false;
        }
    });
    
    // Theme Toggle
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;
    const logoDark = document.getElementById('logo-dark');
    const logoLight = document.getElementById('logo-light');
    
    // Check for saved theme preference or default to dark
    const currentTheme = localStorage.getItem('theme') || 'dark';
    if (currentTheme === 'light') {
        body.classList.add('light-theme');
        if (logoDark && logoLight) {
            logoDark.style.display = 'none';
            logoLight.style.display = 'block';
        }
    }
    
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            body.classList.toggle('light-theme');
            
            // Toggle logos
            if (logoDark && logoLight) {
                if (body.classList.contains('light-theme')) {
                    logoDark.style.display = 'none';
                    logoLight.style.display = 'block';
                } else {
                    logoDark.style.display = 'block';
                    logoLight.style.display = 'none';
                }
            }
            
            // Save theme preference
            const theme = body.classList.contains('light-theme') ? 'light' : 'dark';
            localStorage.setItem('theme', theme);
            
            // Add a little animation effect
            this.style.transform = 'scale(0.9)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    }
    
    // Slide Navigation
    let currentSlide = 1;
    const totalSlides = 13;
    
    function updateSlideCounter() {
        document.getElementById('current-slide').textContent = currentSlide;
        document.getElementById('total-slides').textContent = totalSlides;
    }
    
    function showSlide(slideNumber) {
        // Hide all slides
        document.querySelectorAll('.slide').forEach(slide => {
            slide.classList.remove('active');
        });
        
        // Show current slide
        const targetSlide = document.querySelector(`[data-slide="${slideNumber}"]`);
        if (targetSlide) {
            targetSlide.classList.add('active');
            currentSlide = slideNumber;
            updateSlideCounter();
            
            // Update navigation buttons
            document.getElementById('prev-btn').disabled = currentSlide === 1;
            document.getElementById('next-btn').disabled = currentSlide === totalSlides;
        }
    }
    
    // Navigation event listeners
    document.getElementById('prev-btn').addEventListener('click', function() {
        if (currentSlide > 1) {
            showSlide(currentSlide - 1);
        }
    });
    
    document.getElementById('next-btn').addEventListener('click', function() {
        if (currentSlide < totalSlides) {
            showSlide(currentSlide + 1);
        }
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', function(event) {
        if (event.key === 'ArrowLeft' && currentSlide > 1) {
            showSlide(currentSlide - 1);
        } else if (event.key === 'ArrowRight' && currentSlide < totalSlides) {
            showSlide(currentSlide + 1);
        }
    });
    
    // Touch/Swipe navigation for mobile
    let touchStartX = 0;
    let touchEndX = 0;
    
    const slidesContainer = document.querySelector('.slides-container');
    if (slidesContainer) {
        slidesContainer.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });
        
        slidesContainer.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        }, { passive: true });
        
        function handleSwipe() {
            const swipeThreshold = 50; // Minimum distance for swipe
            const diff = touchStartX - touchEndX;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0 && currentSlide < totalSlides) {
                    // Swipe left - next slide
                    showSlide(currentSlide + 1);
                } else if (diff < 0 && currentSlide > 1) {
                    // Swipe right - previous slide
                    showSlide(currentSlide - 1);
                }
            }
        }
    }
    
    // Initialize
    updateSlideCounter();
    
    // ===== SLIDE 2: Basic Events Demo =====
    const eventDemo1 = document.getElementById('event-demo-1');
    const eventLog1 = document.getElementById('event-log-1');
    
    if (eventDemo1 && eventLog1) {
        function logEvent(eventType, details = '') {
            const timestamp = new Date().toLocaleTimeString();
            eventLog1.innerHTML += `[${timestamp}] ${eventType} ${details}\n`;
            eventLog1.scrollTop = eventLog1.scrollHeight;
        }
        
        eventDemo1.addEventListener('click', () => logEvent('CLICK', 'event fired!'));
        eventDemo1.addEventListener('mouseover', () => logEvent('MOUSEOVER', 'mouse entered'));
        eventDemo1.addEventListener('mouseout', () => logEvent('MOUSEOUT', 'mouse left'));
        eventDemo1.addEventListener('keydown', (e) => logEvent('KEYDOWN', `key: ${e.key}`));
        
        // Make it focusable for keyboard events
        eventDemo1.setAttribute('tabindex', '0');
    }
    
    // ===== SLIDE 3: Event Listeners Demo =====
    const demoButton1 = document.getElementById('demo-button-1');
    const demoButton2 = document.getElementById('demo-button-2');
    const clickCounter = document.getElementById('click-counter');
    
    let clickCount = 0;
    
    if (demoButton1) {
        demoButton1.addEventListener('click', function() {
            clickCount++;
            clickCounter.textContent = `Clicks: ${clickCount}`;
            alert('Single click detected!');
        });
    }
    
    if (demoButton2) {
        demoButton2.addEventListener('dblclick', function(e) {
            e.preventDefault();
            clickCount += 2;
            clickCounter.textContent = `Clicks: ${clickCount}`;
            alert('Double click detected! Added 2 clicks.');
            this.style.background = '#28a745';
            setTimeout(() => {
                this.style.background = '';
            }, 1000);
        });
    }
    
    // ===== SLIDE 4: Mouse Events Demo =====
    const mouseDemoBox = document.getElementById('mouse-demo-box');
    const mouseCoordinates = document.getElementById('mouse-coordinates');
    const mouseEventsLog = document.getElementById('mouse-events-log');
    
    if (mouseDemoBox && mouseEventsLog) {
        function logMouseEvent(eventType, event) {
            const timestamp = new Date().toLocaleTimeString();
            mouseEventsLog.innerHTML += `[${timestamp}] ${eventType}\n`;
            mouseEventsLog.scrollTop = mouseEventsLog.scrollHeight;
        }
        
        mouseDemoBox.addEventListener('click', (e) => {
            logMouseEvent('CLICK', e);
            mouseDemoBox.style.background = '#28a745';
            setTimeout(() => mouseDemoBox.style.background = '#667eea', 500);
        });
        
        mouseDemoBox.addEventListener('dblclick', (e) => {
            logMouseEvent('DOUBLE CLICK', e);
            mouseDemoBox.style.transform = 'rotate(360deg)';
            setTimeout(() => mouseDemoBox.style.transform = 'rotate(0deg)', 500);
        });
        
        mouseDemoBox.addEventListener('mouseover', (e) => {
            logMouseEvent('MOUSE OVER', e);
            mouseDemoBox.style.background = '#764ba2';
        });
        
        mouseDemoBox.addEventListener('mouseout', (e) => {
            logMouseEvent('MOUSE OUT', e);
            mouseDemoBox.style.background = '#667eea';
        });
        
        mouseDemoBox.addEventListener('mousedown', (e) => {
            logMouseEvent('MOUSE DOWN', e);
            mouseDemoBox.style.transform = 'scale(0.95)';
        });
        
        mouseDemoBox.addEventListener('mouseup', (e) => {
            logMouseEvent('MOUSE UP', e);
            mouseDemoBox.style.transform = 'scale(1)';
        });
        
        mouseDemoBox.addEventListener('mousemove', (e) => {
            const rect = mouseDemoBox.getBoundingClientRect();
            const x = Math.round(e.clientX - rect.left);
            const y = Math.round(e.clientY - rect.top);
            mouseCoordinates.textContent = `Mouse Position: (${x}, ${y})`;
        });
    }
    
    // ===== SLIDE 5: Keyboard Events Demo =====
    const keyboardInput = document.getElementById('keyboard-input');
    const lastKey = document.getElementById('last-key');
    const keyCode = document.getElementById('key-code');
    const modifiers = document.getElementById('modifiers');
    const keyboardLog = document.getElementById('keyboard-log');
    
    if (keyboardInput && keyboardLog) {
        function logKeyEvent(eventType, event) {
            const timestamp = new Date().toLocaleTimeString();
            keyboardLog.innerHTML += `[${timestamp}] ${eventType}: ${event.key}\n`;
            keyboardLog.scrollTop = keyboardLog.scrollTop;
        }
        
        keyboardInput.addEventListener('keydown', function(event) {
            logKeyEvent('KEYDOWN', event);
            lastKey.textContent = event.key;
            keyCode.textContent = event.code;
            
            const mods = [];
            if (event.ctrlKey) mods.push('Ctrl');
            if (event.shiftKey) mods.push('Shift');
            if (event.altKey) mods.push('Alt');
            if (event.metaKey) mods.push('Meta');
            
            modifiers.textContent = mods.length > 0 ? mods.join(' + ') : 'None';
            
            // Special key handling
            if (event.key === 'Enter') {
                logKeyEvent('SPECIAL', { key: 'Enter key pressed!' });
            }
        });
        
        keyboardInput.addEventListener('keyup', function(event) {
            logKeyEvent('KEYUP', event);
        });
    }
    
    // ===== SLIDE 6: Form Events Demo =====
    const demoForm = document.getElementById('demo-form');
    const formLog = document.getElementById('form-log');
    
    if (demoForm && formLog) {
        function logFormEvent(eventType, element, value = '') {
            const timestamp = new Date().toLocaleTimeString();
            formLog.innerHTML += `[${timestamp}] ${eventType} on ${element.name || element.id}: ${value}\n`;
            formLog.scrollTop = formLog.scrollHeight;
        }
        
        // Form submission
        demoForm.addEventListener('submit', function(event) {
            event.preventDefault();
            logFormEvent('FORM SUBMIT', this);
            
            const formData = new FormData(this);
            const data = {};
            for (let [key, value] of formData.entries()) {
                data[key] = value;
            }
            
            formLog.innerHTML += `Form Data: ${JSON.stringify(data, null, 2)}\n`;
            alert('Form submitted! Check the log for details.');
        });
        
        // Input events
        const inputs = demoForm.querySelectorAll('input, select');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                logFormEvent('FOCUS', this);
                this.style.borderColor = '#667eea';
            });
            
            input.addEventListener('blur', function() {
                logFormEvent('BLUR', this, this.value);
                this.style.borderColor = '#e2e8f0';
                
                // Simple validation
                if (this.type === 'email' && this.value && !this.value.includes('@')) {
                    this.style.borderColor = '#dc3545';
                    logFormEvent('VALIDATION ERROR', this, 'Invalid email format');
                }
            });
            
            input.addEventListener('change', function() {
                logFormEvent('CHANGE', this, this.value);
            });
            
            input.addEventListener('input', function() {
                logFormEvent('INPUT', this, this.value);
            });
        });
    }
    
    // ===== SLIDE 7: Event Object Demo =====
    const eventObjBtn = document.getElementById('event-obj-btn');
    const preventLink = document.getElementById('prevent-link');
    const eventProperties = document.getElementById('event-properties');
    
    if (eventObjBtn && eventProperties) {
        eventObjBtn.addEventListener('click', function(event) {
            const props = {
                'Event Type': event.type,
                'Target Element': event.target.tagName + (event.target.id ? `#${event.target.id}` : ''),
                'Current Target': event.currentTarget.tagName + (event.currentTarget.id ? `#${event.currentTarget.id}` : ''),
                'Timestamp': new Date(event.timeStamp).toLocaleTimeString(),
                'Bubbles': event.bubbles,
                'Cancelable': event.cancelable,
                'Client X': event.clientX,
                'Client Y': event.clientY
            };
            
            let html = '<h4>Event Object Properties:</h4>';
            for (let [key, value] of Object.entries(props)) {
                html += `<div><strong>${key}:</strong> ${value}</div>`;
            }
            
            eventProperties.innerHTML = html;
        });
    }
    
    if (preventLink) {
        preventLink.addEventListener('click', function(event) {
            event.preventDefault();
            alert('Default behavior prevented! Link navigation was stopped.');
        });
    }
    
    // ===== SLIDE 8: Event Bubbling Demo =====
    const bubblingDemo = document.getElementById('bubbling-demo');
    const toggleBubbling = document.getElementById('toggle-bubbling');
    const bubblingLog = document.getElementById('bubbling-log');
    
    let stopPropagationEnabled = false;
    
    if (bubblingDemo && bubblingLog) {
        function logBubblingEvent(level, event) {
            const timestamp = new Date().toLocaleTimeString();
            bubblingLog.innerHTML += `[${timestamp}] Click on ${level} box\n`;
            bubblingLog.scrollTop = bubblingLog.scrollHeight;
        }
        
        const boxes = bubblingDemo.querySelectorAll('[data-level]');
        boxes.forEach(box => {
            box.addEventListener('click', function(event) {
                const level = this.getAttribute('data-level');
                logBubblingEvent(level, event);
                
                if (stopPropagationEnabled) {
                    event.stopPropagation();
                    bubblingLog.innerHTML += `[${new Date().toLocaleTimeString()}] Propagation stopped at ${level}\n`;
                }
            });
        });
    }
    
    if (toggleBubbling) {
        toggleBubbling.addEventListener('click', function() {
            stopPropagationEnabled = !stopPropagationEnabled;
            this.textContent = stopPropagationEnabled ? 'Enable Bubbling' : 'Toggle stopPropagation()';
            this.style.background = stopPropagationEnabled ? '#dc3545' : '#667eea';
        });
    }
    
    // ===== SLIDE 9: Event Delegation Demo =====
    const addItemBtn = document.getElementById('add-item');
    const itemList = document.getElementById('item-list');
    
    let itemCounter = 3;
    
    if (addItemBtn && itemList) {
        // Event delegation for delete buttons
        itemList.addEventListener('click', function(event) {
            if (event.target.classList.contains('delete-btn')) {
                event.target.parentElement.remove();
            }
        });
        
        // Add new items
        addItemBtn.addEventListener('click', function() {
            itemCounter++;
            const newItem = document.createElement('li');
            newItem.innerHTML = `Item ${itemCounter} <button class="delete-btn">Delete</button>`;
            itemList.appendChild(newItem);
        });
    }
    
    // ===== SLIDE 10: Common Patterns Demo =====
    
    // Toggle Pattern
    const toggleBtn = document.getElementById('toggle-btn');
    const toggleBox = document.getElementById('toggle-box');
    
    if (toggleBtn && toggleBox) {
        toggleBtn.addEventListener('click', function() {
            toggleBox.classList.toggle('hidden');
        });
    }
    
    // Live Validation Pattern
    const validationInput = document.getElementById('validation-input');
    const validationMessage = document.getElementById('validation-message');
    
    if (validationInput && validationMessage) {
        validationInput.addEventListener('input', function() {
            const value = this.value;
            
            if (value.length === 0) {
                validationMessage.textContent = '';
                validationMessage.className = 'validation-message';
            } else if (value.length < 3) {
                validationMessage.textContent = 'Too short! Need at least 3 characters.';
                validationMessage.className = 'validation-message error';
            } else {
                validationMessage.textContent = 'Looks good!';
                validationMessage.className = 'validation-message success';
            }
        });
    }
    
    // Debounced Search Pattern
    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');
    
    if (searchInput && searchResults) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            const query = this.value;
            
            // Clear previous timeout
            clearTimeout(searchTimeout);
            
            // Show loading state
            searchResults.innerHTML = 'Searching...';
            
            // Set new timeout
            searchTimeout = setTimeout(() => {
                if (query.length > 0) {
                    // Simulate search results
                    const mockResults = [
                        'JavaScript Events Tutorial',
                        'Event Handling Best Practices',
                        'DOM Event Reference',
                        'Interactive Web Development'
                    ].filter(item => 
                        item.toLowerCase().includes(query.toLowerCase())
                    );
                    
                    if (mockResults.length > 0) {
                        searchResults.innerHTML = mockResults.map(result => 
                            `<div style="padding: 5px; border-bottom: 1px solid #eee;">${result}</div>`
                        ).join('');
                    } else {
                        searchResults.innerHTML = 'No results found.';
                    }
                } else {
                    searchResults.innerHTML = 'Type to search...';
                }
            }, 300); // 300ms debounce
        });
    }
    
    // ===== EYEBALL INTERACTIVE DEMO =====
    const eyeball = document.getElementById('eyeball');
    
    if (eyeball) {
        const iris = eyeball.querySelector('.iris');
        const eyeballContainer = eyeball.closest('.eyeball-container');
        
        // Array of color classes
        const colors = ['color-blue', 'color-green', 'color-brown', 'color-purple', 'color-amber', 'color-red'];
        let currentColorIndex = -1; // Start with default teal color
        
        // Click to change eye color
        eyeball.addEventListener('click', function(e) {
            e.stopPropagation();
            currentColorIndex = (currentColorIndex + 1) % colors.length;
            
            // Remove all color classes
            colors.forEach(color => iris.classList.remove(color));
            
            // Add new color class
            iris.classList.add(colors[currentColorIndex]);
            
            // Add a little pulse effect
            eyeball.style.transform = 'scale(1.1)';
            setTimeout(() => {
                eyeball.style.transform = 'scale(1)';
            }, 150);
        });
        
        // Make eyeball follow mouse movement with improved accuracy
        if (eyeballContainer) {
            eyeballContainer.addEventListener('mousemove', function(e) {
                const eyeballRect = eyeball.getBoundingClientRect();
                const eyeCenterX = eyeballRect.left + eyeballRect.width / 2;
                const eyeCenterY = eyeballRect.top + eyeballRect.height / 2;
                
                // Calculate angle and distance from eye center to mouse
                const deltaX = e.clientX - eyeCenterX;
                const deltaY = e.clientY - eyeCenterY;
                const angle = Math.atan2(deltaY, deltaX);
                
                // Calculate distance with more realistic movement range
                const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
                const maxDistance = 25; // Maximum pixels the iris can move
                const moveDistance = Math.min(distance / 8, maxDistance);
                
                // Calculate new position
                const x = Math.cos(angle) * moveDistance;
                const y = Math.sin(angle) * moveDistance;
                
                // Apply smooth transform
                iris.style.transform = `translate(${x}px, ${y}px)`;
            });
            
            // Reset iris position when mouse leaves
            eyeballContainer.addEventListener('mouseleave', function() {
                iris.style.transform = 'translate(0, 0)';
            });
        }
    }
    
    // ===== LIGHT SWITCH INTERACTIVE DEMO =====
    const lightSwitch = document.getElementById('light-switch');
    const lightRoom = document.getElementById('light-room');
    
    if (lightSwitch && lightRoom) {
        let lightsOn = false;
        
        lightSwitch.addEventListener('click', function() {
            lightsOn = !lightsOn;
            
            if (lightsOn) {
                lightRoom.classList.add('lights-on');
            } else {
                lightRoom.classList.remove('lights-on');
            }
            
            // Add a little bounce effect to the switch
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 100);
        });
        
        // Add hover effect
        lightSwitch.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05)';
        });
        
        lightSwitch.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    }
    
    // ===== SLIDE 12: Todo App Practice =====
    const todoInput = document.getElementById('todo-input');
    const addTodoBtn = document.getElementById('add-todo');
    const todoList = document.getElementById('todo-list');
    const todoStats = document.getElementById('todo-stats');
    
    let todos = [];
    
    function updateTodoStats() {
        const total = todos.length;
        const completed = todos.filter(todo => todo.completed).length;
        todoStats.textContent = `Total: ${total} | Completed: ${completed}`;
    }
    
    function renderTodos() {
        todoList.innerHTML = '';
        todos.forEach((todo, index) => {
            const li = document.createElement('li');
            li.className = todo.completed ? 'completed' : '';
            li.innerHTML = `
                <span>${todo.text}</span>
                <button class="delete-btn" data-index="${index}">Delete</button>
            `;
            li.addEventListener('click', function(event) {
                if (!event.target.classList.contains('delete-btn')) {
                    todos[index].completed = !todos[index].completed;
                    renderTodos();
                    updateTodoStats();
                }
            });
            todoList.appendChild(li);
        });
        updateTodoStats();
    }
    
    function addTodo() {
        const text = todoInput.value.trim();
        if (text === '') {
            alert('Please enter a todo item!');
            return;
        }
        
        todos.push({
            text: text,
            completed: false
        });
        
        todoInput.value = '';
        renderTodos();
    }
    
    if (todoInput && addTodoBtn && todoList) {
        // Event delegation for delete buttons
        todoList.addEventListener('click', function(event) {
            if (event.target.classList.contains('delete-btn')) {
                const index = parseInt(event.target.getAttribute('data-index'));
                todos.splice(index, 1);
                renderTodos();
            }
        });
        
        // Add todo button
        addTodoBtn.addEventListener('click', addTodo);
        
        // Enter key to add todo
        todoInput.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                addTodo();
            }
        });
        
        // Initialize with some sample todos
        todos = [
            { text: 'Learn JavaScript Events', completed: true },
            { text: 'Practice Event Handling', completed: false },
            { text: 'Build Interactive Web Pages', completed: false }
        ];
        renderTodos();
    }
    
    // Add some visual feedback for all interactive elements
    document.querySelectorAll('.demo-btn, .nav-btn').forEach(btn => {
        btn.addEventListener('mousedown', function() {
            this.style.transform = 'scale(0.95)';
        });
        
        btn.addEventListener('mouseup', function() {
            this.style.transform = 'scale(1)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
});

// Additional utility functions for demonstrations
function showAlert(message) {
    alert(message);
}

function logToConsole(message) {
    console.log(`[Demo] ${message}`);
}

// Make some functions globally available for inline demonstrations
window.demoFunctions = {
    showAlert,
    logToConsole
};